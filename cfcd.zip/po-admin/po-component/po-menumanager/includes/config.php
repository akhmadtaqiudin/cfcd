<?php
// Tables Settings
define('MENU_TABLE', 'menu');
define('MENUGROUP_TABLE', 'menu_group');

// Fields Settings
define('MENU_ID', 'id');
define('MENU_PARENT', 'parent_id');
define('MENU_TITLE', 'title');
define('MENU_URL', 'url');
define('MENU_CLASS', 'class');
define('MENU_POSITION', 'position');
define('MENU_GROUP', 'group_id');

define('MENUGROUP_ID', 'id');
define('MENUGROUP_TITLE', 'title');

/* End of config.php */
?>