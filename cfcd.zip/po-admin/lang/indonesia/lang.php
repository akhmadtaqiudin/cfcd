<?php
//Menu
$langmenu1 = 'Beranda';
$langmenu2 = 'Post';
$langmenu3 = 'Semua Post';
$langmenu4 = 'Tambah Baru';
$langmenu5 = 'Kategori';
$langmenu6 = 'Tag';
$langmenu7 = 'Media';
$langmenu8 = 'Pustaka';
$langmenu9 = 'Tambah Baru';
$langmenu10 = 'Halaman';
$langmenu11 = 'Semua Halaman';
$langmenu12 = 'Tambah Baru';
$langmenu13 = 'Tampilan';
$langmenu14 = 'Pengaturan';
$langmenu15 = 'Tema';
$langmenu16 = 'Komponen';
$langmenu17 = 'Semua Komponen';
$langmenu18 = 'Tambah Baru';
$langmenu19 = 'Pengguna';
$langmenu20 = 'Semua Pengguna';
$langmenu21 = 'Tambah Baru';
$langmenu22 = 'Keluar';
$langmenu23 = 'PENGATURAN';
$langmenu24 = 'Navigasi';
$langmenu25 = 'Konten';
$langmenu26 = 'Pesan';
$langmenu27 = 'Profil';
$langmenu28 = 'Menu Manager';
$langmenu29 = 'Akses Cepat';
$langmenu30 = 'Ke Front End';
$langmenu31 = 'Komponen Terpasang';
$langmenu32 = 'Profil';

//Beranda
$langhome1 = 'Beranda';
$langhome2 = 'Selamat datang di halaman administrator';
$langhome3 = 'Statistik Konten';
$langhome4 = 'Post';
$langhome5 = 'Kategori';
$langhome6 = 'Tag';
$langhome7 = 'Media';
$langhome8 = 'Halaman';
$langhome9 = 'Komponen';
$langhome10 = 'Pengguna';
$langhome11 = 'Statistik Pengunjung 4 hari yang lalu';
$langhome12 = 'Total';
$langhome13 = 'Pengunjung';
$langhome14 = 'Klik';
$langhome15 = 'Dari Pengunjung';
$langhome16 = 'Pilih Bahasa :';
$langhome17 = 'Anda memiliki';
$langhome18 = 'komentar baru';
$langhome19 = 'pesan baru';
$langhome20 = 'Bahasa';
$langhome21 = 'Backup Basis Data';
$langhome22 = 'Selamat datang di halaman member';
$langhome23 = 'post baru yang belum disetujui';

//Halaman Tidak Ditemukan
$langpagenotfound1 = 'Halaman Tidak Ditemukan';
$langpagenotfound2 = 'Ke Beranda';
$langpagenotfound3 = 'Ke Sebelumnya';

//Popoup Hapus
$langdelete1 = 'Konfirmasi Penghapusan';
$langdelete2 = 'Apakah Anda yakin akan menghapus data ini?';
$langdelete3 = 'Ya';
$langdelete4 = 'Tidak';

//Aksi
$langaction1 = 'Ubah Data';
$langaction2 = 'Hapus';
$langaction3 = 'Ke Komponen';
$langaction4 = 'Impor Tabel';
$langaction5 = 'Pilih Semua';

//Tabel Post
$langpost1 = 'Manajemen Post';
$langpost2 = 'Tambah, ubah dan hapus manajemen post';
$langpost3 = 'Kategori';
$langpost4 = 'Judul Id';
$langpost5 = 'Judul En';
$langpost6 = 'Aktif';
$langpost7 = 'Tindakan';

//Tabel Kategori
$langcategory1 = 'Manajemen Kategori';
$langcategory2 = 'Tambah, ubah dan hapus manajemen kategori';
$langcategory3 = 'Judul Id';
$langcategory4 = 'Judul En';
$langcategory5 = 'Aktif';
$langcategory6 = 'Tindakan';
$langcategory7 = 'Tambah Kategori';

//Tabel Tag
$langtag1 = 'Manajemen Tag';
$langtag2 = 'Tambah dan hapus manajemen tag';
$langtag3 = 'Judul';
$langtag4 = 'Jumlah';
$langtag5 = 'Tindakan';
$langtag6 = 'Tambah Tag';

//Tabel Media
$langlibrary1 = 'Manajemen Media';
$langlibrary2 = 'Tambah dan hapus manajemen media';
$langlibrary3 = 'Nama';
$langlibrary4 = 'Tipe';
$langlibrary5 = 'Ukuran';
$langlibrary6 = 'Tanggal';
$langlibrary7 = 'Tindakan';
$langlibrary8 = 'Gambar';
$langlibrary9 = 'Berkas';

//Tabel Halaman
$langpages1 = 'Manajemen Halaman';
$langpages2 = 'Tambah, ubah dan hapus manajemen halaman';
$langpages3 = 'Judul Id';
$langpages4 = 'Judul En';
$langpages5 = 'Aktif';
$langpages6 = 'Tindakan';

//Tabel Pengaturan
$langsetting1 = 'Manajemen Pengaturan';
$langsetting2 = 'Ubah manajemen pengaturan';
$langsetting3 = 'Judul';
$langsetting4 = 'Konten';
$langsetting5 = 'Nama Website';
$langsetting6 = 'Url Website';
$langsetting7 = 'Deskripsi Meta';
$langsetting8 = 'Kata Kunci Meta';
$langsetting9 = 'Ikon Favorit';
$langsetting10 = 'Klik pada konten untuk mengganti data';
$langsetting11 = 'Ganti';
$langsetting12 = 'Pilih';
$langsetting13 = 'Tema Admin';
$langsetting14 = 'Zona Waktu';
$langsetting15 = 'Zona Waktu Aktif';
$langsetting16 = 'Tanggal dan Waktu Aktif';
$langsetting17 = 'Bantuan';
$langsetting18 = 'Mode Maintenance';
$langsetting19 = 'Aktif';
$langsetting20 = 'Deaktif';
$langsetting21 = 'Web Cache';
$langsetting22 = 'Jam';
$langsetting23 = 'Hari';
$langsetting24 = 'Email';
$langsetting25 = 'Hapus Cache Tersimpan';
$langsetting26 = 'Pendaftaran Anggota';

//Tabel Tema
$langtheme1 = 'Manajemen Tema';
$langtheme2 = 'Tambah dan hapus manajemen tema';
$langtheme3 = 'Tambah Baru';
$langtheme4 = 'Dibuat Oleh';
$langtheme5 = 'Hapus';
$langtheme6 = 'Nonaktifkan';
$langtheme7 = 'Aktifkan';
$langtheme8 = 'Edit Tema Aktif';
$langtheme9 = 'Klik icon disamping kanan untuk mengedit file lainnya';

//Tabel Komponen
$langcomponent1 = 'Manajemen Komponen';
$langcomponent2 = 'Atur dan hapus manajemen komponen';
$langcomponent3 = 'Komponen';
$langcomponent4 = 'Tanggal';
$langcomponent5 = 'Tabel';
$langcomponent6 = 'Tindakan';
$langcomponent7 = 'Masukkan nama komponen dengan aturan nama komponen harus sama dengan nama folder dimana komponen diletakkan.';
$langcomponent8 = 'Contoh: po-gallery karena nama foldernya po-gallery';
$langcomponent9 = 'Masukkan nama tabel dengan aturan nama tabel harus sama dengan nama tabel pada database yang nantinya akan dibuat.';
$langcomponent10 = 'Kosongkan nama tabel jika tidak ada tabel yang akan dibuat nantinya.';
$langcomponent11 = 'Sebelum menginstall komponen sebaiknya membaca berkas "baca saya" dari si pembuat komponen.';
$langcomponent12 = 'Berkas yang diupload harus berekstensi sql.';
$langcomponent13 = 'Cek kembali berkas sql yang akan diupload, apakah nama tabel yang akan dibuat sudah sama dengan nama tabel pada komponen atau belum.';
$langcomponent14 = 'Jika terjadi duplikasi tabel, maka tabel yang lama akan ditimpa dengan tabel yang baru (berhati-hatilah).';
$langcomponent15 = 'Instruksi';

//Tabel Pengguna
$languser1 = 'Manajemen Pengguna';
$languser2 = 'Tambah dan ubah manajemen pangguna';
$languser3 = 'Nama User';
$languser4 = 'Nama Lengkap';
$languser5 = 'Level';
$languser6 = 'Blokir';
$languser7 = 'Tindakan';
?>