<?php
/**
* Management Bahasa
*/

$QueryResultAlign		= "center";
$displayQueryTitleColor = "lightblue";
$displayQueryBgColor 	= "#CCCCCC";

$browseColor1		= "#EEEEEE";
$browseColor2		= "#DDDDDD";
$browseColorOver		= "yellow";
$browseColorClick		= "lightgreen";

//$bahasa_author  	= '<br/>Jenuar Dwi Putra Dalapang';
//$bahasa_contact 	= 'mailto:djenuar@gmail.com';
?>
