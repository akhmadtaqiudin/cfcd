tinymce.addI18n('es',{
	'YouTube Title' : "Insertar un vídeo de YouTube",
	'Youtube URL'	: 'Enlace para compartir',
	'Youtube ID'    : 'Formato de enlace para compartir: http://youtu.be/xxxxxxxx ó http://www.youtube.com/watch?v=xxxxxxxx',
	'width'			: 'Ancho',
	'height'		: 'Alto',
	'autoplay'		: 'Autoplay',
	'Related video' : 'Vídeos relacionados',
	'HD video'      : 'Ver en HD'
});