tinymce.addI18n('de',{
	'YouTube Title' : "Einfügen von YouTube-Videos",
	'Youtube URL'	: 'Youtube-Link',
	'Youtube ID'    : 'Link-Format : http://youtu.be/xxxxxxxx  oder http://www.youtube.com/watch?v=xxxxxxxx',
	'width'			: 'Breite',
	'height'		: 'Hoehe',
	'autoplay'		: 'Automatische Wiedergabe?',
	'Related video' : 'Verwandte Videos anzeigen?',
	'HD video'      : 'In HD abspielen?'
});